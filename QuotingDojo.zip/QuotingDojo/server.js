const express = require("express");
const app = express();
app.use(express.static(__dirname + "/static"));
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));


const mongoose = require('mongoose')
mongoose.connect('mongodb://localhost/Quotes', {useNewUrlParser: true});

const QuoteSchema = new mongoose.Schema({
    name: {type: String, required: true, minlength: 2},
    quote: {type: String, required: true, minlength: 2}
}, {timestamps: true})
const Quote = mongoose.model('Quote', QuoteSchema)


app.get('/', (request, response) => {
   response.render("index");
});


app.get('/quotes', (request, response) => {
    Quote.find()
        
        .then(data => response.render("quotes", { Quote : data }))
        .catch(err => response.json(err));
 });


 app.post('/quotes', (req, res) => {
     console.log(req.body +"**********************")
    const quote = new Quote();
    quote.name = req.body.name;
    quote.quote = req.body.quote;
    quote.save()
      .then(newQuoteData => res.redirect("/quotes"))
      .catch(err => console.log(err));
     
    res.redirect('/quotes');
  })


 app.listen(8000, () => console.log("listening on port 8000"));


 // morning list:
 //start mongo db, shell crud a few quotes, get ADD for post route logic, run server